import { Link } from "@tanstack/react-router";
import logo from "@/assets/logo.png";
import { Flag, ALLY_CODES } from "@/components/Flag";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/60 bg-background/70">
      <div className="mx-auto max-w-7xl px-6 py-14">
        <div className="grid gap-10 md:grid-cols-6">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3">
              <img src={logo} alt="Save Britain" className="h-12 w-12 rounded-full bg-white object-contain p-0.5 ring-2 ring-gold/40" />
              <span className="font-serif text-xl text-gradient-gold">Save Britain</span>
            </div>
            <p className="mt-4 max-w-md text-sm text-muted-foreground">
              A British political movement in formation. Building long-term national stability,
              economic renewal, industrial revival and constitutional sovereignty for the United Kingdom.
            </p>
            <p className="mt-3 text-xs text-muted-foreground">
              Not yet registered with the Electoral Commission. Registration intended by 2028–2029.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {ALLY_CODES.map((c) => <Flag key={c} code={c} className="h-5 w-7 rounded-sm shadow ring-1 ring-black/30" />)}
            </div>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold text-gold">Movement</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/about" className="hover:text-foreground">About</Link></li>
              <li><Link to="/framework" className="hover:text-foreground">Framework</Link></li>
              <li><Link to="/program" className="hover:text-foreground">Political Program</Link></li>
              <li><Link to="/leadership" className="hover:text-foreground">Leadership</Link></li>
              <li><Link to="/constitution" className="hover:text-foreground">Constitution</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold text-gold">Doctrine</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/manifesto" className="hover:text-foreground">Manifesto</Link></li>
              <li><Link to="/policies" className="hover:text-foreground">Policies</Link></li>
              <li><Link to="/bill-of-rights" className="hover:text-foreground">Bill of Rights</Link></li>
              <li><Link to="/timeline" className="hover:text-foreground">32-Year Plan</Link></li>
              <li><Link to="/allies" className="hover:text-foreground">Allies & Trade</Link></li>
              <li><a href="/British-Bill-Of-Rights-And-Freedoms-Act.pdf" target="_blank" rel="noreferrer" className="hover:text-foreground">Bill PDF</a></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold text-gold">Take action</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/join" className="hover:text-foreground">Join</Link></li>
              <li><Link to="/donate" className="hover:text-foreground">Donate (temporarily closed)</Link></li>
              <li><a href="/save-britain-poster.png" download className="hover:text-foreground">Download poster</a></li>
              <li><a href="/save-britain-source.zip" download className="hover:text-foreground">Download site (ZIP)</a></li>
            </ul>
          </div>
        </div>
        <div className="hairline my-10" />
        <div className="flex flex-col items-center justify-between gap-3 text-xs text-muted-foreground md:flex-row">
          <span>© {new Date().getFullYear()} Save Britain. All rights reserved.</span>
          <span className="uppercase tracking-[0.2em]">Structure · Stability · Renewal</span>
        </div>
      </div>
    </footer>
  );
}
