export function Flag({ code, className = "h-6 w-9 rounded-sm shadow ring-1 ring-black/30" }: { code: string; className?: string }) {
  return (
    <img
      src={`https://flagcdn.com/w160/${code.toLowerCase()}.png`}
      srcSet={`https://flagcdn.com/w320/${code.toLowerCase()}.png 2x`}
      width={48}
      height={32}
      alt={`${code.toUpperCase()} flag`}
      loading="lazy"
      className={className}
    />
  );
}

export const ALLY_CODES = ["gb", "us", "ca", "au", "nz", "it", "tw", "pl", "de", "jp"] as const;
