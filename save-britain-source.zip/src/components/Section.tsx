import { ReactNode } from "react";

export function PageHeader({ eyebrow, title, lead }: { eyebrow?: string; title: string; lead?: string }) {
  return (
    <section className="border-b border-border/50">
      <div className="mx-auto max-w-5xl px-6 py-20 text-center">
        {eyebrow && <div className="mb-4 text-xs uppercase tracking-[0.3em] text-gold">{eyebrow}</div>}
        <h1 className="font-serif text-4xl md:text-6xl font-semibold text-gradient-gold">{title}</h1>
        {lead && <p className="mx-auto mt-6 max-w-2xl text-base text-muted-foreground md:text-lg">{lead}</p>}
      </div>
    </section>
  );
}

export function Section({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <section className={`mx-auto max-w-6xl px-6 py-16 ${className}`}>{children}</section>
  );
}
