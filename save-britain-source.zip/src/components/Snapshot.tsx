import { ReactNode } from "react";

// Snapshot button removed by request — this component now simply wraps its children
// so existing imports/usages across pages continue to work without UI noise.
export function Snapshot({
  children,
  className = "",
}: {
  filename?: string;
  children: ReactNode;
  className?: string;
  label?: string;
}) {
  return <div className={className}>{children}</div>;
}
