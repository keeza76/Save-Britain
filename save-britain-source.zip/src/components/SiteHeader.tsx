import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, Download, FileArchive, Lock } from "lucide-react";
import logo from "@/assets/logo.png";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/framework", label: "Framework" },
  { to: "/program", label: "Program" },
  { to: "/manifesto", label: "Manifesto" },
  { to: "/policies", label: "Policies" },
  { to: "/bill-of-rights", label: "Bill of Rights" },
  { to: "/timeline", label: "32-Year Plan" },
  { to: "/allies", label: "Allies" },
  { to: "/constitution", label: "Constitution" },
  { to: "/leadership", label: "Leadership" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur-xl">
      <div className="stripe-flag" />
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-3">
        <Link to="/" className="flex items-center gap-3 shrink-0">
          <img src={logo} alt="Save Britain logo" className="h-12 w-12 rounded-full bg-white object-contain p-0.5 ring-2 ring-[var(--gold)]/50" />
          <div className="leading-tight">
            <div className="font-serif text-lg font-semibold tracking-tight text-gradient-gold">Save Britain</div>
            <div className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">Welcome · Structure · Renewal</div>
          </div>
        </Link>

        <nav className="hidden items-center gap-4 xl:flex">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className="text-sm text-foreground/80 transition-colors hover:text-[var(--gold)]" activeProps={{ className: "text-[var(--gold)]" }}>
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 xl:flex shrink-0">
          <a href="/save-britain-poster.png" download className="inline-flex items-center gap-1.5 rounded-md border border-[var(--gold)]/40 px-3 py-2 text-xs font-semibold text-[var(--gold)] hover:bg-[var(--gold)]/10" title="Download the Save Britain poster">
            <Download className="h-3.5 w-3.5" /> Poster
          </a>
          <a href="/save-britain-source.zip" download className="inline-flex items-center gap-1.5 rounded-md border border-[var(--gold)]/40 px-3 py-2 text-xs font-semibold text-[var(--gold)] hover:bg-[var(--gold)]/10" title="Download all website source files (ZIP)">
            <FileArchive className="h-3.5 w-3.5" /> Site ZIP
          </a>
          <Link to="/join" className="rounded-md border border-[var(--gold)]/40 px-3 py-2 text-sm font-semibold text-[var(--gold)] hover:bg-[var(--gold)]/10">Join</Link>
          <Link to="/donate" className="inline-flex items-center gap-1.5 rounded-md bg-muted/40 px-3 py-2 text-sm font-semibold text-muted-foreground" title="Donations temporarily closed">
            <Lock className="h-3.5 w-3.5" /> Donate
          </Link>
        </div>

        <button className="xl:hidden" onClick={() => setOpen((v) => !v)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <div className="border-t border-border/50 xl:hidden">
          <div className="mx-auto flex max-w-7xl flex-col gap-1 px-6 py-3">
            {links.map((l) => (
              <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="rounded px-2 py-2 text-sm hover:bg-muted">
                {l.label}
              </Link>
            ))}
            <div className="mt-2 grid grid-cols-2 gap-2">
              <a href="/save-britain-poster.png" download className="inline-flex items-center justify-center gap-1.5 rounded-md border border-[var(--gold)]/40 px-3 py-2 text-xs font-semibold text-[var(--gold)]">
                <Download className="h-3.5 w-3.5" /> Poster
              </a>
              <a href="/save-britain-source.zip" download className="inline-flex items-center justify-center gap-1.5 rounded-md border border-[var(--gold)]/40 px-3 py-2 text-xs font-semibold text-[var(--gold)]">
                <FileArchive className="h-3.5 w-3.5" /> Site ZIP
              </a>
            </div>
            <Link to="/join" onClick={() => setOpen(false)} className="mt-2 rounded-md border border-[var(--gold)]/40 px-3 py-2 text-center text-sm font-semibold text-[var(--gold)]">Join</Link>
            <Link to="/donate" onClick={() => setOpen(false)} className="rounded-md bg-muted/40 px-3 py-2 text-center text-sm font-semibold text-muted-foreground">Donate (closed)</Link>
          </div>
        </div>
      )}
    </header>
  );
}
