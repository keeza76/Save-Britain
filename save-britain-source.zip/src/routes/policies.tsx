import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { FileText, Download, Fuel, Car } from "lucide-react";

export const Route = createFileRoute("/policies")({ component: Policies });

const policies = [
  { c: "Economy", title: "Rebuild British Industry", body: "National Industrial Strategy for steel, shipbuilding, automotive, engineering, semiconductors, gaming and creative industries — anchored in regional jobs." },
  { c: "Economy", title: "Support Small Business", body: "Targeted support for SMEs, startups and independent creators. Simpler rules, fairer competition, faster payment terms enforced by law." },
  { c: "Economy", title: "Wage Indexation", body: "Statutory wage indexation against cost-of-living indicators. Criminal penalties for systematic wage exploitation." },
  { c: "Economy", title: "UK Procurement Preference", body: "British-supply-chain preference in all major public procurement where viable. End offshoring of strategic state contracts." },
  { c: "Economy", title: "National Infrastructure Bank", body: "Public investment bank financing long-term infrastructure, housing, energy and reindustrialisation." },
  { c: "Economy", title: "Abolish Vehicle Excise Duty (VED)", body: "Vehicle Excise Duty — paying tax simply to own a car — does not fund road maintenance and is a fundamentally unfair tax on lawful drivers. Save Britain will abolish VED by statute, fold the lost revenue into general taxation, and lock the repeal into the Bill of Rights schedule so it cannot be re-imposed." },
  { c: "Industry", title: "Protect Petrol & Diesel Cars — 500-Year Lock", body: "End the petrol and diesel ban date and protect British petrol-car production for a guaranteed minimum of 500 years. Boost UK petrol-car production capacity by 99% over the renewal period. Cap EV-mandate quotas. Locked by constitutional statute in the Bill of Rights schedule — no future government, court or treaty body may amend, suspend or repeal." },
  { c: "Industry", title: "Revive British Shipbuilding", body: "Rebuild merchant and naval shipbuilding capacity in Scotland, Tyneside, Belfast and Merseyside." },
  { c: "Industry", title: "Steel Sovereignty", body: "Reopen and expand strategic primary steel production. Public stake in core foundries. End reliance on imported strategic steel." },
  { c: "Industry", title: "Semiconductor & AI Compute", body: "National semiconductor design and packaging capacity. Strategic UK compute reserve for science, defence and AI." },
  { c: "Industry", title: "Aerospace & Defence Manufacturing", body: "Expanded UK contribution to GCAP, AUKUS, NATO joint programmes. Rebuild domestic missile, drone and electronics production." },
  { c: "Energy", title: "Energy Independence Mix", body: "Balanced nuclear, gas, oil and renewable mix. Domestic energy security prioritised over external dependence." },
  { c: "Energy", title: "Repeal the Petrol Ban — Permanently", body: "Repeal the 2030/2035 petrol and diesel ban and protect petrol-car production for 500 years. Lock repeal into the Bill of Rights schedule." },
  { c: "Housing", title: "Housing First Nationally", body: "Statutory right to emergency accommodation. Integrated recovery pathway — housing, mental health and addiction support." },
  { c: "Housing", title: "Fast-Track Planning Zones", body: "Designated zones for rapid affordable housing delivery with binding regional supply targets." },
  { c: "Housing", title: "Vacant Property Restriction", body: "Restrictions on long-term vacant property holdings. Priority allocation for UK residents in need and key workers." },
  { c: "NHS", title: "Strengthen the NHS", body: "Universal public healthcare protected. Reform respecting clinicians, reducing waiting times, expanding training and retention. Free at the point of use — always." },
  { c: "NHS", title: "Mental Health Parity", body: "Mental-health funding and access raised to parity with physical health. Crisis-bed expansion programme." },
  { c: "Borders", title: "End the Asylum Pipeline", body: "End all irregular Channel crossings. End indefinite asylum and refugee acceptance. Replace with capped, government-selected resettlement." },
  { c: "Borders", title: "Deport Foreign Criminals", body: "No ECHR Article 8 block. Foreign nationals convicted of serious offences are removed without delay." },
  { c: "Borders", title: "Capacity-Based Migration", body: "Lawful migration ceilings linked dynamically to housing, NHS, labour and infrastructure capacity." },
  { c: "Borders", title: "Migration Referendum System", body: "Periodic public referenda on migration ceilings and categories. Migration policy democratically owned." },
  { c: "Constitution", title: "British Bill of Rights & Freedoms Act", body: "Sovereign UK rights legislation. Lawful withdrawal from the ECHR. UK courts answer only to UK law." },
  { c: "Constitution", title: "Semi-Constitutional Monarchy", body: "A stabilising constitutional monarchy alongside decisive parliamentary governance under the dual-authority model." },
  { c: "Constitution", title: "Independent Audit Authority", body: "Statutory anti-corruption authority. Mandatory publication of performance metrics across departments." },
  { c: "Defence", title: "Royal Navy Expansion", body: "Expanded surface fleet, submarine programme delivered via AUKUS, restored Royal Marines amphibious capability." },
  { c: "Defence", title: "RAF & Air Capability", body: "Tempest / GCAP delivery. Expanded UK-based maintenance and pilot training. Long-range strike capability restored." },
  { c: "Defence", title: "Cyber & Infrastructure Protection", body: "National Cyber Force expansion. Statutory protection of energy, water, telecoms and transport networks." },
  { c: "Culture", title: "Heritage & Culture", body: "Preserve historic landmarks and Britain's cultural heritage as protected elements of the national fabric." },
  { c: "Culture", title: "Freedom of Expression", body: "Lawful expression — including unpopular political and religious speech — constitutionally safeguarded." },
  { c: "Foreign Policy", title: "Strategic Alliance Circle", body: "Deepened alliance with USA, Canada, Australia, NZ, Italy, Taiwan, Poland, Germany and Japan." },
  { c: "Foreign Policy", title: "Wide Trade Expansion", body: "Largest possible commercial trade footprint — China and USA as top-volume partners, plus Italy, Canada and Indo-Pacific expansion." },
  { c: "Foreign Policy", title: "NATO Military-Tech Sharing", body: "Joint defence-tech programmes — GCAP, AUKUS, cyber, AI, missile and armour cooperation with NATO allies." },
];

const categories = Array.from(new Set(policies.map((p) => p.c)));

function Policies() {
  return (
    <div>
      <PageHeader eyebrow="Policy Platform" title="Policies for a stable, sovereign Britain" lead="Practical, long-term policy designed to strengthen institutions, the economy, industry, borders, defence and everyday life." />

      <Section className="py-8">
        <div className="card-premium rounded-2xl p-6">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Browse by category</div>
          <div className="mt-4 flex flex-wrap gap-2">
            {categories.map((c) => (
              <a key={c} href={`#cat-${c}`} className="rounded-full border border-gold/30 bg-background/40 px-4 py-2 text-xs font-semibold text-foreground/85 transition hover:border-gold hover:bg-gold/10 hover:text-gold">
                {c}
              </a>
            ))}
          </div>
        </div>
      </Section>

      <Section className="pt-0">
        <div className="grid gap-6 md:grid-cols-2 mb-10">
          <div className="card-premium rounded-2xl p-8 border-gold/40">
            <div className="flex items-start gap-4">
              <div className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-lg gradient-gold text-primary-foreground glow-cyan">
                <Fuel className="h-6 w-6" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-[var(--gold)]">Locked Statute · 500-Year Protection</div>
                <h3 className="mt-2 font-serif text-2xl">The Petrol-Car Protection Pledge</h3>
                <p className="mt-3 text-muted-foreground">
                  Save Britain will end the petrol and diesel car ban date and protect British petrol-car
                  production for a guaranteed minimum of <span className="text-[var(--gold)]">500 years</span>,
                  increase UK petrol-car production by <span className="text-[var(--gold)]">99%</span> over the
                  renewal period, cap EV-mandate quotas, and write this protection into the schedule of the
                  British Bill of Rights and Freedoms Act so
                  <span className="text-[var(--gold)]"> no future government, court or treaty body may amend, suspend or repeal it</span>.
                </p>
              </div>
            </div>
          </div>
          <div className="card-premium rounded-2xl p-8 border-gold/40">
            <div className="flex items-start gap-4">
              <div className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-lg gradient-gold text-primary-foreground glow-cyan">
                <Car className="h-6 w-6" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-[var(--gold)]">Abolition Pledge</div>
                <h3 className="mt-2 font-serif text-2xl">Abolish Vehicle Excise Duty (VED)</h3>
                <p className="mt-3 text-muted-foreground">
                  In the UK, Vehicle Excise Duty (commonly called car tax) is mandatory and helps fund public
                  services — but it is <span className="text-[var(--gold)]">not</span> specifically allocated for
                  road maintenance. That is an unfair tax on lawful drivers. Save Britain will
                  <span className="text-[var(--gold)]"> abolish VED entirely</span>, fold the lost revenue into
                  general taxation, and lock the repeal into the Bill of Rights schedule so it can never be
                  re-imposed by a future government.
                </p>
              </div>
            </div>
          </div>
        </div>

        {categories.map((c) => (
          <div key={c} id={`cat-${c}`} className="scroll-mt-24 mb-12">
            <div className="mb-5 flex items-baseline justify-between">
              <h2 className="font-serif text-2xl md:text-3xl text-gradient-gold">{c}</h2>
              <span className="text-xs uppercase tracking-[0.3em] text-muted-foreground">{policies.filter(p => p.c === c).length} policies</span>
            </div>
            <div className="hairline mb-6" />
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {policies.filter((p) => p.c === c).map((p) => (
                <div key={p.title} className="card-premium rounded-xl p-6">
                  <h3 className="font-serif text-lg text-gradient-gold">{p.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.body}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </Section>

      <Section className="pt-0">
        <div className="card-premium flex flex-col items-start gap-6 rounded-2xl p-8 md:flex-row md:items-center md:justify-between">
          <div className="flex items-start gap-4">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-gold">Proposed legislation</div>
              <h3 className="mt-1 font-serif text-2xl">British Bill of Rights and Freedoms Act</h3>
              <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
                Our flagship framework to restore sovereign UK rights legislation and lawfully withdraw from the ECHR.
              </p>
            </div>
          </div>
          <a href="/British-Bill-Of-Rights-And-Freedoms-Act.pdf" target="_blank" rel="noreferrer"
             className="inline-flex items-center gap-2 rounded-md gradient-gold px-5 py-3 text-sm font-semibold text-primary-foreground">
            <Download className="h-4 w-4" /> Download PDF
          </a>
        </div>
      </Section>
    </div>
  );
}
