import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { Snapshot } from "@/components/Snapshot";
import { Crown, Users, Landmark, Scale, BadgeCheck, Building2 } from "lucide-react";

export const Route = createFileRoute("/framework")({
  component: Framework,
  head: () => ({
    meta: [
      { title: "Party Framework — Save Britain" },
      { name: "description", content: "The structural framework of the Save Britain Party — organisation, governance, ideological position, and operating model." },
      { property: "og:title", content: "Party Framework — Save Britain" },
      { property: "og:description", content: "The structural framework of the Save Britain Party." },
    ],
  }),
});

const orgs = [
  { icon: Crown, h: "Party Leader", b: "Elected by full members. Sets strategic direction. Accountable to the National Executive Committee and to members through annual confidence vote." },
  { icon: Users, h: "Deputy Leader", b: "Supports the Leader, leads parliamentary or organisational portfolio assigned by the NEC." },
  { icon: Landmark, h: "National Executive Committee (NEC)", b: "Governs party operations between conferences. Sets internal discipline, candidate selection rules, and approves the manifesto." },
  { icon: BadgeCheck, h: "Statutory Treasurer", b: "Required under PPERA 2000. Responsible for all donation compliance, accounts and Electoral Commission reporting." },
  { icon: Scale, h: "Statutory Nominating Officer", b: "Required under PPERA 2000. Approves all candidates standing under the Save Britain name." },
  { icon: Building2, h: "Regional & Branch Network", b: "Constituency branches, regional councils, and a national conference. Members elect branch officers and regional representatives." },
];

const operating = [
  { h: "Ideology", b: "Full Social Democracy operating through a Nordic-style efficient state, a regulated social market economy, and a One-Nation framework." },
  { h: "Governance Model", b: "Dual-authority constitutional model — constitutional monarchy as stabilising authority alongside decisive parliamentary governance under the Prime Minister." },
  { h: "Decision-Making", b: "Members vote on motions, candidate selection, and manifesto pillars. NEC governs operational matters between conferences." },
  { h: "Funding Model", b: "Members-first funding. Minimum £4.99/month membership donation. No paid 'founder' rank. Foreign donations refused. PPERA 2000 compliance." },
  { h: "Transparency", b: "Annual audited accounts published. Quarterly NEC reports to members. Independent integrity oversight at national level once in government." },
  { h: "Discipline", b: "Formal internal investigations for misconduct. Right of appeal. Removal only via defined constitutional procedures." },
];

function Framework() {
  return (
    <div>
      <PageHeader
        eyebrow="Party Framework"
        title="How Save Britain is built"
        lead="The structural framework of the Save Britain Party — organisational hierarchy, governance, ideological position, and the operating model that holds the movement together."
      />

      <Section>
        <Snapshot filename="save-britain-framework-organisation">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Organisational structure</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">The six pillars of party organisation</h2>
            <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {orgs.map((o) => (
                <div key={o.h} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                  <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                    <o.icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-serif text-lg text-gradient-gold">{o.h}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{o.b}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="save-britain-framework-operating-model">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Operating model</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">How we operate as a movement</h2>
            <div className="mt-8 grid gap-5 md:grid-cols-2">
              {operating.map((o) => (
                <div key={o.h} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                  <h3 className="font-serif text-lg text-gradient-gold">{o.h}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{o.b}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <div className="card-premium rounded-2xl p-10 text-center">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Framework Principle</div>
          <blockquote className="mx-auto mt-4 max-w-3xl font-serif text-2xl leading-relaxed md:text-3xl">
            “The party belongs to its <span className="text-gradient-gold">members</span> — not its donors,
            not its founders, not its leaders.”
          </blockquote>
        </div>
      </Section>
    </div>
  );
}
