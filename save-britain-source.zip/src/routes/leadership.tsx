import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";

export const Route = createFileRoute("/leadership")({ component: Leadership });

const founders = [
  { name: "Kieran Dixon", role: "Founder & Party Leader", initials: "KD", bio: "Founder of the Save Britain movement. Focused on long-term institutional reform, economic renewal, and constitutional stability for the United Kingdom." },
  { name: "Luke Milligan", role: "Founder & Deputy Chair", initials: "LM", bio: "Co-founder and Deputy Chair. Focused on organisational structure, policy development and the long-term roadmap toward formal registration." },
];

function Leadership() {
  return (
    <div>
      <PageHeader eyebrow="Founding Leadership" title="The people building Save Britain" lead="Save Britain is built by people who believe in long-term national strength over short-term politics." />
      <Section>
        <div className="grid gap-8 md:grid-cols-2">
          {founders.map((f) => (
            <div key={f.name} className="card-premium rounded-2xl p-8">
              <div className="flex items-center gap-5">
                <div className="grid h-20 w-20 place-content-center rounded-full gradient-gold font-serif text-2xl text-primary-foreground shadow-lg shadow-gold/10">
                  {f.initials}
                </div>
                <div>
                  <h3 className="font-serif text-2xl">{f.name}</h3>
                  <div className="text-sm text-gold">{f.role}</div>
                </div>
              </div>
              <p className="mt-6 text-sm leading-relaxed text-muted-foreground">{f.bio}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {["National Executive Committee", "Treasurer (statutory)", "Nominating Officer (statutory)"].map((r) => (
            <div key={r} className="rounded-xl border border-gold/20 bg-background/40 p-5 text-center">
              <div className="text-xs uppercase tracking-[0.25em] text-gold">Role</div>
              <div className="mt-1 font-serif">{r}</div>
              <div className="mt-1 text-xs text-muted-foreground">Appointments forthcoming</div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}
