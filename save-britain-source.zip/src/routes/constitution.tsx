import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { Snapshot } from "@/components/Snapshot";

export const Route = createFileRoute("/constitution")({ component: Constitution });

const sections = [
  { n: "I", title: "Name", body: "The Party shall be known as the Save Britain Party." },
  { n: "II", title: "Status & Development Timeline", body: "Save Britain operates as a political movement in formation. Structured national campaigning and fundraising begin in late 2027. Membership, local branches and national organisation will be built through 2027–2028. A formal application to the Electoral Commission will be submitted by 14 May 2028, or no later than 2029, subject to full legal compliance and organisational readiness." },
  { n: "III", title: "Objectives", body: "To strengthen the UK's democratic institutions and sovereignty; improve living standards; reduce poverty, homelessness and regional inequality; rebuild national economic and industrial capability; maintain constitutional monarchy and parliamentary democracy; ensure lawful and controlled migration; strengthen national resilience; and lawfully replace the European Convention on Human Rights with the British Bill of Rights and Freedoms Act." },
  { n: "IV", title: "Core Principles", body: "Parliamentary democracy. Constitutional monarchy. Rule of law. Equality before the law. Free elections and peaceful transfer of power. Freedom of speech within UK legal boundaries. National sovereignty and independent decision-making. Industrial protection." },
  { n: "V", title: "International Policy & Sovereignty", body: "The United Kingdom shall operate as a fully sovereign democratic state. The Party supports lawful withdrawal from or reform of international agreements only through Parliament, full independence of UK domestic lawmaking, trade-based cooperation rather than political integration, bilateral agreements in the national interest, and rejection of external bodies exercising legislative control over UK law." },
  { n: "VI", title: "Leadership Structure", body: "Party Leader, Deputy Leader, National Executive Committee, Treasurer (statutory) and Nominating Officer (statutory). Regional councils and constituency branches. National conference held annually. All roles must comply with UK electoral law." },
  { n: "VII", title: "Membership", body: "Open to UK residents eligible to vote, who support Party principles and comply with lawful conduct requirements. Full membership granted to any permissible donor pledging £4.99 or more per month. No 'founder' or 'patron' rank may be purchased. Equal treatment under UK law guaranteed." },
  { n: "VIII", title: "Candidate Selection", body: "Internal vetting required. Candidates must comply with UK electoral eligibility law. Integrity and conduct declaration mandatory. Approval by the National Executive Committee." },
  { n: "IX", title: "Finance & Transparency", body: "Full compliance with Electoral Commission funding rules. No unlawful foreign donations. Annual audited accounts published. Transparent reporting of all donations and expenditure." },
  { n: "X", title: "Discipline & Governance", body: "Formal internal investigation for misconduct. Right of appeal guaranteed. Removal only through defined constitutional procedures." },
  { n: "XI", title: "Constitutional Compliance", body: "Full adherence to UK law. Respect for judicial independence and parliamentary sovereignty. Commitment to peaceful democratic process." },
  { n: "XII", title: "The 32-Year Renewal Mandate", body: "On election to government, Save Britain shall propose a one-time, constitutionally-bound 32-year national renewal mandate across twenty-five delivery eras, subject to a binding sunset clause that automatically dissolves the mandate on Year 32 + 1 day, triggers a general election within 30 days, and permanently reinstates the standard UK 5-year electoral cycle." },
  { n: "XIII", title: "Locked Protections", body: "Save Britain shall introduce, via the Schedule of the British Bill of Rights and Freedoms Act, permanent protections that no future government may amend or repeal without national referendum — including petrol-car production protection, sovereign borders, and the renewal sunset clause itself." },
];

function Constitution() {
  return (
    <div>
      <PageHeader eyebrow="Electoral Commission Constitution (Draft)" title="The Save Britain Constitution" lead="The founding document of the Save Britain movement, as drafted during its formation phase." />
      <Section>
        <Snapshot filename="save-britain-constitution">
          <div className="card-premium rounded-2xl p-8 md:p-10">
            <div className="space-y-6">
              {sections.map((s) => (
                <article key={s.n} className="rounded-xl border border-gold/15 bg-background/40 p-7">
                  <div className="flex items-start gap-5">
                    <div className="font-serif text-3xl text-gradient-gold w-12 shrink-0">{s.n}</div>
                    <div>
                      <h3 className="font-serif text-xl">{s.title}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
            <div className="mt-10 rounded-xl border border-gold/20 bg-gold/5 p-7 text-center">
              <div className="text-xs uppercase tracking-[0.3em] text-gold">Closing Statement</div>
              <p className="mx-auto mt-3 max-w-3xl text-muted-foreground">
                This Constitution defines the Save Britain Party during its formation phase. The Party is currently
                building its organisational structure ahead of formal political activity. Until formal registration —
                <span className="text-gold"> we remain Save Britain.</span>
              </p>
            </div>
          </div>
        </Snapshot>
      </Section>
    </div>
  );
}
