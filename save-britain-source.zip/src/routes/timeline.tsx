import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { Clock, Vote, Hammer, RotateCcw } from "lucide-react";

export const Route = createFileRoute("/timeline")({
  component: Timeline,
  head: () => ({
    meta: [
      { title: "The 32-Year National Renewal Period — Save Britain" },
      { name: "description", content: "Save Britain's 32-year renewal mandate across twenty-five delivery eras — followed by the permanent restoration of the 5-year electoral cycle." },
      { property: "og:title", content: "The 32-Year National Renewal Period" },
      { property: "og:description", content: "A 32-year delivery mandate across 25 eras, followed by full restoration of the 5-year electoral cycle." },
    ],
  }),
});

const eras = [
  { y: "Era I · Years 1",       h: "Inauguration & Audit",            b: "Full government spending audit. Independent National Integrity & Audit Authority stood up. Emergency homelessness response activated. Cabinet performance metrics published quarterly from day one." },
  { y: "Era II · Year 2",       h: "Bill of Rights Drafted",          b: "British Bill of Rights and Freedoms Act introduced to Parliament. Public consultation launched. ECHR Article 58 withdrawal notice lodged with the Council of Europe." },
  { y: "Era III · Year 3",      h: "ECHR Withdrawal Completed",       b: "Lawful withdrawal from the European Convention on Human Rights completed. Domestic rights transition plan in force. UK courts answer only to UK law." },
  { y: "Era IV · Year 4",       h: "Bill of Rights Enacted",          b: "British Bill of Rights and Freedoms Act receives Royal Assent. Locked Schedule of permanent protections established — petrol-car protection embedded." },
  { y: "Era V · Year 5",        h: "Borders Closed to the Pipeline",  b: "Channel crossings dismantled. Asylum and refugee pipeline closed. Capped, government-selected resettlement programme launched. Foreign criminal removal accelerated." },
  { y: "Era VI · Years 6–7",    h: "Wage & Cost-of-Living Reset",     b: "Statutory wage indexation enforced. Criminal penalties for wage exploitation in operation. Apprenticeship pipeline scaled to every major infrastructure contract." },
  { y: "Era VII · Years 7–8",   h: "Industrial Reignition",           b: "National Industrial Strategy live. Steel, shipbuilding, automotive, semiconductor revival begun. Petrol-car production expansion programme launches towards the 99% target." },
  { y: "Era VIII · Years 8–10", h: "Housing Stabilisation",           b: "Housing First enshrined nationally. Fast-track planning zones operational. Regional supply targets enforced. Street homelessness reduced toward zero." },
  { y: "Era IX · Years 10–12",  h: "NHS Reconstruction",              b: "NHS workforce rebuilt. Waiting list targets met. Mental health funding raised to parity with physical health. Hospital capital plan delivered." },
  { y: "Era X · Years 12–14",   h: "Energy Independence",             b: "UK energy independence delivered through balanced nuclear (SMR + large reactor), gas, oil and renewable mix. Petrol & diesel ban formally repealed — 500-year protection locked." },
  { y: "Era XI · Years 14–15",  h: "Vehicle Excise Duty Abolished",   b: "Vehicle Excise Duty (car tax / VED) abolished by statute. Replaced by lawful general taxation. Locked into Bill of Rights schedule." },
  { y: "Era XII · Years 15–17", h: "Royal Navy Expansion",            b: "Surface fleet expanded. AUKUS submarine programme operational. Royal Marines amphibious capability restored. Merchant marine reinforced." },
  { y: "Era XIII · Years 17–18",h: "RAF Tempest / GCAP Delivery",     b: "Tempest / GCAP combat-air system in operational service with Italy and Japan. Domestic pilot training, MRO and long-range strike capability scaled." },
  { y: "Era XIV · Years 18–19", h: "NATO Frontline Posture",          b: "Permanent NATO frontline rotational presence in the Baltic. Joint armour and missile programmes with Poland and Germany delivered." },
  { y: "Era XV · Years 19–20",  h: "Education & Skills Maturity",     b: "National apprenticeship pipeline matured. Skills-based migration replaces low-skill imports. Technical colleges and trade institutes nationally rebuilt." },
  { y: "Era XVI · Years 20–21", h: "Northern Industrial Renewal",     b: "North-East and North-West reindustrialisation programmes completed. Tyneside, Merseyside, Hull, Teesside heavy industry restored." },
  { y: "Era XVII · Years 21–22",h: "Scottish & Welsh Renewal",        b: "Scottish shipbuilding doubled. Welsh steel and energy capacity expanded. Devolved settlements aligned to the One-Nation framework." },
  { y: "Era XVIII · Years 22–23",h: "Cornwall & SW Renewal",          b: "Cornish, Devon and South-West industrial, tin, lithium and aerospace programmes operational. Coastal regeneration delivered." },
  { y: "Era XIX · Years 23–24", h: "Strategic Alliance Lock-in",      b: "Treaty-level deepening with USA, Canada, Australia, NZ, Italy, Taiwan, Poland, Germany, Japan. CPTPP & Commonwealth trade expanded." },
  { y: "Era XX · Years 24–25",  h: "Wide Trade Expansion",            b: "China and USA confirmed as top-volume commercial partners. Italy and Canada confirmed as deep bilateral partnerships. No foreign legislative control over UK law." },
  { y: "Era XXI · Years 25–26", h: "Civic & Rights Maturity",         b: "Rights & Responsibility Charter embedded in public service delivery. Freedom of expression case law in force. Labour and housing exploitation crushed." },
  { y: "Era XXII · Years 26–28",h: "Constitutional Lock-In",          b: "Bill of Rights, ECHR withdrawal, petrol-car protection, VED abolition and sunset clause embedded permanently. Locked Schedule unreachable by future amendment." },
  { y: "Era XXIII · Years 28–30",h: "Audit & Anti-Corruption Maturity", b: "Independent National Integrity & Audit Authority fully operational. Mandatory department performance metrics published quarterly. Corruption prosecutions complete." },
  { y: "Era XXIV · Years 30–31",h: "Handover Preparation",            b: "Election infrastructure restored. Boundary review delivered. Independent electoral commission re-empowered. Cabinet handover protocols issued." },
  { y: "Era XXV · Years 31–32", h: "Democratic Reset",                b: "Final performance report published. Sunset clause activates on Year 32 + 1 day. General election called within 30 days. Standard UK 5-year cycle permanently reinstated." },
];

function Timeline() {
  return (
    <div>
      <PageHeader
        eyebrow="The Renewal Doctrine"
        title="The 32-Year National Renewal Period"
        lead="A single, time-limited delivery mandate across twenty-five eras to rebuild Britain — followed by the full, permanent restoration of the 5-year electoral cycle and a general election thereafter."
      />

      <Section>
        <div className="grid gap-5 md:grid-cols-3">
          <Card icon={Clock} h="32 Years of Delivery" b="One uninterrupted national renewal mandate. Five years is not enough; institutions cannot be rebuilt on a single political cycle, and even 25 was not enough to lock the reforms in place." />
          <Card icon={Hammer} h="Built, Not Debated" b="Structural change — industry, NHS, housing, defence, borders, energy, VED abolition, petrol-car protection — is engineered and embedded, not endlessly relitigated." />
          <Card icon={RotateCcw} h="Then the Cycle Resumes" b="After 32 years, the standard UK 5-year general election cycle is automatically and permanently reinstated by constitutional sunset clause." />
        </div>
      </Section>

      <Section className="pt-0">
        <div className="text-xs uppercase tracking-[0.3em] text-[var(--gold)]">Why 32 years</div>
        <h2 className="mt-3 font-serif text-3xl md:text-4xl">Five wasn't enough. Eighteen wasn't enough. Twenty-five wasn't enough.</h2>
        <div className="mt-6 space-y-4 max-w-4xl text-foreground/90">
          <p>
            Britain's deepest problems — collapsing housing supply, NHS waiting lists, deindustrialisation,
            border failure, regional inequality, broken infrastructure, the loss of domestic manufacturing —
            were not built in five years and cannot be solved in five, ten, eighteen or even twenty-five. Every
            UK government in living memory has been forced to abandon long-term reform halfway through, because
            the next election forces a reset.
          </p>
          <p>
            Save Britain proposes a one-time, constitutionally-defined 32-year national renewal mandate across
            twenty-five delivery eras. During this period, the standard general-election cycle is paused so
            that long-term reforms — Bill of Rights enactment, ECHR withdrawal, industrial reconstruction,
            housing delivery, defence modernisation, NHS rebuild, energy independence, petrol-car expansion,
            and the abolition of Vehicle Excise Duty — can be completed under continuous, accountable
            governance.
          </p>
          <p>
            After 32 years the doctrine self-terminates by binding sunset clause. The 5-year electoral cycle
            resumes automatically, a general election is called within 30 days, and the United Kingdom returns
            to its standard democratic rhythm — with the renewal already <span className="text-[var(--gold)]">built</span>,
            not still under debate.
          </p>
        </div>
      </Section>

      <Section className="pt-0">
        <div className="card-premium rounded-2xl p-8 md:p-12">
          <div className="text-xs uppercase tracking-[0.3em] text-[var(--gold)]">The twenty-five eras</div>
          <h2 className="mt-3 font-serif text-3xl md:text-4xl">Thirty-two years, twenty-five delivery eras</h2>
          <p className="mt-3 max-w-3xl text-muted-foreground">
            Each era has a defined start, a defined deliverable, and a published performance report at its
            conclusion. Eras are sequenced so that constitutional and rights work happens first, structural
            economic rebuilding follows, and democratic handover closes the mandate.
          </p>
          <div className="relative mt-10 space-y-6 before:absolute before:left-4 before:top-2 before:bottom-2 before:w-px before:bg-[var(--gold)]/30 md:before:left-1/2">
            {eras.map((p, i) => (
              <div key={p.y} className={`relative grid gap-6 md:grid-cols-2 ${i % 2 === 1 ? "md:[&>*:first-child]:order-2" : ""}`}>
                <div className="card-premium ml-12 rounded-xl p-6 md:ml-0">
                  <div className="text-xs uppercase tracking-[0.3em] text-[var(--gold)]">{p.y}</div>
                  <h3 className="mt-2 font-serif text-xl text-gradient-gold">{p.h}</h3>
                  <p className="mt-3 text-sm text-muted-foreground">{p.b}</p>
                </div>
                <div className="hidden md:block" />
                <div className="absolute left-4 top-8 h-3 w-3 rounded-full bg-[var(--gold)] ring-4 ring-background md:left-1/2 md:-translate-x-1/2" />
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Section className="pt-0">
        <div className="card-premium rounded-2xl p-10">
          <div className="flex items-start gap-4">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground glow-cyan">
              <Vote className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.3em] text-[var(--gold)]">The Sunset Clause</div>
              <h3 className="mt-2 font-serif text-2xl md:text-3xl">Year 32 + 1 day: democracy resumes in full</h3>
              <p className="mt-4 max-w-3xl text-muted-foreground">
                A constitutional sunset clause — written into the founding renewal act — automatically
                dissolves the renewal mandate on its 32nd anniversary, triggers a general election within 30
                days, and permanently reinstates the standard UK 5-year electoral cycle. The clause cannot be
                extended, renewed, or repeated. One mandate. One generation. Then power returns to the ballot
                box.
              </p>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}

function Card({ icon: Icon, h, b }: { icon: React.ComponentType<{ className?: string }>; h: string; b: string }) {
  return (
    <div className="card-premium rounded-xl p-6">
      <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
        <Icon className="h-5 w-5" />
      </div>
      <h3 className="font-serif text-lg text-gradient-gold">{h}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{b}</p>
    </div>
  );
}
