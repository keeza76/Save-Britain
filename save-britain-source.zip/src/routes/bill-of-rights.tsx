import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { FileText, Download, Scale, Shield, Gavel, BookOpen, Fuel, Lock } from "lucide-react";
import { Snapshot } from "@/components/Snapshot";

export const Route = createFileRoute("/bill-of-rights")({
  component: BillOfRights,
  head: () => ({
    meta: [
      { title: "British Bill of Rights and Freedoms Act — Save Britain" },
      { name: "description", content: "Save Britain's proposed Bill of Rights and Freedoms Act — restoring sovereign UK rights legislation and lawfully replacing the ECHR with a domestic framework." },
      { property: "og:title", content: "British Bill of Rights and Freedoms Act" },
      { property: "og:description", content: "A sovereign UK rights framework — replacing the ECHR with a domestic Bill of Rights and Freedoms." },
    ],
  }),
});

const pillars = [
  { icon: Scale, h: "Sovereign UK Rights Framework", b: "A domestically authored, parliamentary-supreme charter of rights and freedoms — written, interpreted and amended only by the United Kingdom." },
  { icon: Gavel, h: "Lawful ECHR Withdrawal", b: "Orderly, treaty-compliant withdrawal from the European Convention on Human Rights, replaced in full by the British Bill of Rights and Freedoms Act." },
  { icon: Shield, h: "Citizenship-First Protections", b: "Rights protected for UK citizens and lawful residents under UK law — paired with explicit civic responsibilities." },
  { icon: BookOpen, h: "Plain-English Drafting", b: "A clear, readable rights document every citizen can understand — not a legal labyrinth interpreted abroad." },
];

const freedoms = [
  "Freedom of expression within UK law",
  "Freedom of conscience, belief and worship",
  "Freedom of peaceful assembly and protest",
  "Freedom of the press and editorial independence",
  "Right to fair trial and due process",
  "Equality before the law for all citizens and lawful residents",
  "Right to private family life and home",
  "Right to property and lawful enjoyment",
  "Right to vote in free, lawful UK elections",
  "Protection from arbitrary detention or state overreach",
  "Right to access information held by the state",
  "Protection from discrimination on lawful protected grounds",
];

const enabled = [
  { h: "End the Asylum & Refugee Pipeline", b: "Lawful withdrawal from the 1951 Refugee Convention obligations and replacement of the asylum framework with a sovereign UK system. Stop irregular Channel crossings, dismantle people-smuggling routes, end indefinite asylum and refugee intake. Genuine humanitarian cases via tightly capped, capacity-tested, government-selected resettlement only." },
  { h: "Deport Foreign Criminals", b: "ECHR Article 8 'right to family life' claims will no longer block the removal of foreign nationals convicted of serious offences." },
  { h: "Strengthen Border Enforcement", b: "Immediate removal of illegal entrants. Detention pending removal. No automatic claim of asylum upon irregular arrival." },
  { h: "Restore Parliamentary Supremacy", b: "UK courts answer only to UK law. No foreign court overrides Acts of Parliament." },
  { h: "Protect Free Speech", b: "Lawful expression — including unpopular political and religious speech — is constitutionally safeguarded." },
  { h: "Defend Veterans and Armed Forces", b: "End vexatious foreign-court prosecutions of British soldiers acting under lawful UK military command." },
];

const lockedSchedule = [
  { icon: Fuel, h: "Petrol-Car Protection", b: "The petrol and diesel ban is permanently repealed and locked in. UK petrol-car production capacity expanded by 99%. EV-mandate quotas capped. No future government may amend or repeal this protection." },
  { icon: Lock, h: "Renewal Sunset Clause", b: "The 25-year national renewal mandate is bound by sunset clause — automatic dissolution on Year 25 + 1 day, general election within 30 days, permanent return of the 5-year cycle." },
  { icon: Shield, h: "Sovereign Borders Lock", b: "No future treaty or convention may re-impose mandatory asylum or refugee acceptance on the United Kingdom without express, repeated Act of Parliament and national referendum." },
];

function BillOfRights() {
  return (
    <div>
      <PageHeader
        eyebrow="Flagship Legislation"
        title="British Bill of Rights and Freedoms Act"
        lead="A sovereign UK rights framework. Drafted in Britain, interpreted in Britain, amended in Britain — replacing the European Convention on Human Rights with a domestic Bill of Rights and Freedoms."
      />

      <Section>
        <div className="card-premium flex flex-col items-start gap-6 rounded-2xl p-8 md:flex-row md:items-center md:justify-between">
          <div className="flex items-start gap-4">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-gold">Published draft</div>
              <h3 className="mt-1 font-serif text-2xl">The Full Legislative Draft</h3>
              <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
                Read the complete proposed text of the British Bill of Rights and Freedoms Act,
                including ECHR withdrawal mechanism and sovereign rights schedule.
              </p>
            </div>
          </div>
          <a href="/British-Bill-Of-Rights-And-Freedoms-Act.pdf" target="_blank" rel="noreferrer"
             className="inline-flex items-center gap-2 rounded-md gradient-gold px-5 py-3 text-sm font-semibold text-primary-foreground">
            <Download className="h-4 w-4" /> Download the PDF
          </a>
        </div>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="bill-of-rights-pillars">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Four pillars</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">What the Act establishes</h2>
            <div className="mt-8 grid gap-5 md:grid-cols-2">
              {pillars.map((p) => (
                <div key={p.h} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                  <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                    <p.icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-serif text-lg text-gradient-gold">{p.h}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.b}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="bill-of-rights-freedoms">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">The Rights Schedule</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">Twelve protected freedoms</h2>
            <div className="mt-8 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {freedoms.map((f) => (
                <div key={f} className="flex items-start gap-3 rounded-lg border border-gold/15 bg-background/40 p-4">
                  <span className="mt-1.5 inline-block h-1 w-3 shrink-0 bg-gold/80" />
                  <span className="text-sm">{f}</span>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="bill-of-rights-enabled">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">What becomes legally possible</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">After Royal Assent, the UK is lawfully empowered to:</h2>
            <div className="mt-8 grid gap-5 md:grid-cols-2">
              {enabled.map((e) => (
                <div key={e.h} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                  <h3 className="font-serif text-lg text-gradient-gold">{e.h}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{e.b}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="bill-of-rights-locked-schedule">
          <div className="card-premium rounded-2xl p-8 border-gold/40">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Locked Schedule · Cannot be amended or repealed</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">Permanent protections written into the Bill</h2>
            <p className="mt-3 max-w-3xl text-muted-foreground">
              The Schedule of the British Bill of Rights and Freedoms Act contains protections that no future
              government, Parliament, or treaty may amend or repeal without explicit national referendum.
            </p>
            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {lockedSchedule.map((s) => (
                <div key={s.h} className="rounded-xl border border-gold/30 bg-gold/5 p-6">
                  <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                    <s.icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-serif text-lg text-gradient-gold">{s.h}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.b}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <div className="card-premium rounded-2xl p-10 text-center">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">The Principle</div>
          <blockquote className="mx-auto mt-4 max-w-3xl font-serif text-2xl leading-relaxed md:text-3xl">
            “British rights, written by the British Parliament, judged by British courts,
            <span className="text-gradient-gold"> for the British people.</span>”
          </blockquote>
        </div>
      </Section>
    </div>
  );
}
