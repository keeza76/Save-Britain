import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { Snapshot } from "@/components/Snapshot";
import { Target, ListChecks, Hammer, Layers } from "lucide-react";

export const Route = createFileRoute("/program")({
  component: Program,
  head: () => ({
    meta: [
      { title: "Political Program — Save Britain" },
      { name: "description", content: "Save Britain's full political program: goals, policy proposals, action plans, and the planks of our platform." },
      { property: "og:title", content: "Political Program — Save Britain" },
      { property: "og:description", content: "Goals, policy proposals, action plans, and planks of the Save Britain platform." },
    ],
  }),
});

const goals = [
  "Restore long-term national stability across all UK regions",
  "Rebuild domestic industrial and manufacturing capability",
  "Deliver universal high-quality public services with Nordic-grade efficiency",
  "Re-establish full UK sovereignty over rights and law",
  "End the asylum and refugee intake pipeline through lawful reform",
  "Eliminate street homelessness as a structural outcome",
  "Achieve UK energy independence through a balanced mix",
  "Modernise the Royal Navy, Army and RAF to full sovereign capability",
  "Strengthen the strategic alliance circle and maximise global trade",
  "Lock long-term reforms via constitutional sunset and protection clauses",
];

const proposals = [
  { c: "Social", items: ["Universal NHS protected and reconstructed", "Housing First nationally", "Wage indexation against cost of living", "Mental-health parity with physical health", "Statutory right to emergency accommodation"] },
  { c: "Economic", items: ["National Industrial Strategy", "National Infrastructure Investment Bank", "UK procurement preference in public contracts", "SME tax simplification", "Petrol-car production expansion of 99%"] },
  { c: "Political", items: ["British Bill of Rights and Freedoms Act", "Lawful ECHR withdrawal", "Independent National Integrity & Audit Authority", "Dual-authority constitutional model", "32-year renewal mandate across 25 eras with sunset clause"] },
  { c: "Security & Borders", items: ["End the asylum and refugee pipeline", "Deport foreign criminals — no Article 8 block", "Capacity-based migration ceilings", "Royal Navy + RAF modernisation", "National Cyber Force expansion"] },
];

const actions = [
  { h: "Legislative Track", b: "Introduce the Bill of Rights in the first 14 days. ECHR withdrawal notice lodged by Day 42. Royal Assent achieved by Day 98." },
  { h: "Industrial Track", b: "Stand up steel, shipbuilding, automotive and semiconductor task forces by Day 49. National Industrial Strategy published by Day 63." },
  { h: "Border Track", b: "Channel-crossing enforcement scaled from Day 14. Foreign Criminal Removal Order activated by Day 70." },
  { h: "Public Services Track", b: "NHS workforce rescue package + Housing First enshrinement within the first 56 days. Hospital capital plan by Day 56." },
  { h: "Foreign Policy Track", b: "Strategic alliance summit with the nine partner nations by Day 91. Trade expansion missions to China, USA, Italy, Canada by Day 91." },
  { h: "Audit Track", b: "Independent Integrity & Audit Authority established by Day 77. Department performance metrics published quarterly thereafter." },
];

const planks = [
  { h: "Plank 1 · Sovereignty", b: "UK courts answer only to UK law. No foreign tribunal overrides Acts of Parliament." },
  { h: "Plank 2 · Petrol-Car Protection", b: "Permanent repeal of the petrol & diesel ban. 99% production expansion. Locked into the Bill of Rights schedule." },
  { h: "Plank 3 · NHS Protected", b: "Universal public healthcare, free at the point of use, always." },
  { h: "Plank 4 · End Asylum Pipeline", b: "End indefinite asylum/refugee acceptance. Sovereign capped resettlement only." },
  { h: "Plank 5 · Housing First", b: "Statutory right to emergency accommodation. End street homelessness." },
  { h: "Plank 6 · Reindustrialise", b: "Steel, shipbuilding, automotive, aerospace, semiconductors revived in the UK." },
  { h: "Plank 7 · Wage Indexation", b: "Statutory wage growth indexed to cost-of-living indicators." },
  { h: "Plank 8 · Defence Modernisation", b: "Royal Navy expansion, RAF Tempest/GCAP, AUKUS submarines, NATO frontline presence." },
  { h: "Plank 9 · Energy Independence", b: "Balanced nuclear, gas, oil and renewable mix. No hostile-supply-chain dependency." },
  { h: "Plank 10 · Strategic Alliances", b: "Deep ties with USA, Canada, Australia, NZ, Italy, Taiwan, Poland, Germany, Japan." },
  { h: "Plank 11 · Wide Trade", b: "Maximum commercial trade with China, USA, Italy, Canada and the Commonwealth." },
  { h: "Plank 12 · Audit & Integrity", b: "Independent statutory anti-corruption authority with enforcement powers." },
  { h: "Plank 13 · Dual Authority", b: "Constitutional monarchy + decisive parliamentary governance under PM." },
  { h: "Plank 14 · Free Speech", b: "Lawful expression — including unpopular political/religious speech — constitutionally safeguarded." },
  { h: "Plank 15 · Renewal Sunset Clause", b: "32-year renewal mandate, with binding return to 5-year electoral cycle." },
];

function Program() {
  return (
    <div>
      <PageHeader
        eyebrow="The Political Program"
        title="Goals, Proposals, Action Plans & Planks"
        lead="The full political program of Save Britain — what we aim to achieve, the specific policies that achieve it, the action plans that implement them, and the planks of the overall platform."
      />

      <Section>
        <Snapshot filename="save-britain-program-goals">
          <div className="card-premium rounded-2xl p-8">
            <div className="flex items-start gap-4">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                <Target className="h-6 w-6" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-gold">Goals & Objectives</div>
                <h2 className="mt-2 font-serif text-3xl">What Save Britain aims to achieve</h2>
              </div>
            </div>
            <ul className="mt-8 grid gap-3 md:grid-cols-2">
              {goals.map((g, i) => (
                <li key={g} className="flex items-start gap-3 rounded-lg border border-gold/15 bg-background/40 p-4">
                  <div className="grid h-8 w-8 shrink-0 place-content-center rounded gradient-gold text-xs font-bold text-primary-foreground">{i + 1}</div>
                  <span className="text-sm text-foreground/90 pt-1">{g}</span>
                </li>
              ))}
            </ul>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="save-britain-program-proposals">
          <div className="card-premium rounded-2xl p-8">
            <div className="flex items-start gap-4">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                <ListChecks className="h-6 w-6" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-gold">Policy Proposals</div>
                <h2 className="mt-2 font-serif text-3xl">Specific plans for social, economic and political renewal</h2>
              </div>
            </div>
            <div className="mt-8 grid gap-5 md:grid-cols-2">
              {proposals.map((p) => (
                <div key={p.c} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                  <h3 className="font-serif text-lg text-gradient-gold">{p.c}</h3>
                  <ul className="mt-3 space-y-2 text-sm text-foreground/85">
                    {p.items.map((i) => <li key={i} className="flex gap-2"><span className="mt-2 h-1 w-3 shrink-0 bg-gold/70" /><span>{i}</span></li>)}
                  </ul>
                </div>
              ))}
            </div>
            <p className="mt-6 text-sm text-muted-foreground">See the full <Link to="/policies" className="text-gold hover:underline">Policies catalogue</Link> for every individual proposal.</p>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="save-britain-program-action-plans">
          <div className="card-premium rounded-2xl p-8">
            <div className="flex items-start gap-4">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                <Hammer className="h-6 w-6" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-gold">Action Plans</div>
                <h2 className="mt-2 font-serif text-3xl">How we implement, on which track, by when</h2>
              </div>
            </div>
            <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {actions.map((a) => (
                <div key={a.h} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                  <h3 className="font-serif text-lg text-gradient-gold">{a.h}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{a.b}</p>
                </div>
              ))}
            </div>
            <p className="mt-6 text-sm text-muted-foreground">Full schedule on the <Link to="/manifesto" className="text-gold hover:underline">15-phase 100-day plan</Link> and the <Link to="/timeline" className="text-gold hover:underline">32-year renewal timeline</Link>.</p>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="save-britain-program-planks">
          <div className="card-premium rounded-2xl p-8">
            <div className="flex items-start gap-4">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                <Layers className="h-6 w-6" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-gold">Planks</div>
                <h2 className="mt-2 font-serif text-3xl">Fifteen building blocks of the platform</h2>
              </div>
            </div>
            <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {planks.map((p) => (
                <div key={p.h} className="rounded-xl border border-gold/15 bg-background/40 p-5">
                  <h3 className="font-serif text-base text-gradient-gold">{p.h}</h3>
                  <p className="mt-2 text-xs text-muted-foreground">{p.b}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>
    </div>
  );
}
