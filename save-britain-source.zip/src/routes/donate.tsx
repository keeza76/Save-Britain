import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { Lock, Bell, Shield } from "lucide-react";

export const Route = createFileRoute("/donate")({
  component: Donate,
  head: () => ({
    meta: [
      { title: "Donations Temporarily Closed — Save Britain" },
      { name: "description", content: "Save Britain donations are temporarily closed while we finalise our Electoral-Commission-compliant payment portal. They will be back online soon." },
    ],
  }),
});

function Donate() {
  return (
    <div>
      <PageHeader
        eyebrow="Donations · Temporarily Closed"
        title="We've paused donations — for now"
        lead="To stay fully compliant with UK electoral law while we finalise our payment, audit and verification systems, donations are temporarily closed. They will be back online very soon."
      />

      <Section>
        <div className="mx-auto max-w-3xl">
          <div className="card-premium rounded-2xl p-10 text-center">
            <div className="mx-auto grid h-16 w-16 place-content-center rounded-full gradient-gold text-primary-foreground glow-cyan">
              <Lock className="h-7 w-7" />
            </div>
            <h2 className="mt-6 font-serif text-3xl text-gradient-gold">Donations are temporarily closed</h2>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              Welcome to Save Britain. We have temporarily paused all membership and donation
              pledges while we complete our donor-verification and Electoral-Commission compliance
              process. This is a short, deliberate pause — donations <span className="text-[var(--gold)]">will be back soon</span>.
            </p>

            <div className="mt-8 grid gap-4 sm:grid-cols-3 text-left">
              <Info icon={Bell} h="Get notified" b="Join the movement now and you'll be the first to know the moment donations re-open." />
              <Info icon={Shield} h="Lawful & transparent" b="When live, every donation will be processed under the Political Parties, Elections and Referendums Act 2000." />
              <Info icon={Lock} h="No rank for sale" b="Membership will never be tier-based. No founder, patron or pillar status will be purchasable." />
            </div>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link to="/join" className="rounded-md gradient-gold px-6 py-3 text-sm font-semibold text-primary-foreground glow-cyan">
                Join the movement
              </Link>
              <Link to="/manifesto" className="rounded-md border border-[var(--gold)]/40 px-6 py-3 text-sm font-semibold text-[var(--gold)] hover:bg-[var(--gold)]/10">
                Read the manifesto
              </Link>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}

function Info({ icon: Icon, h, b }: { icon: React.ComponentType<{ className?: string }>; h: string; b: string }) {
  return (
    <div className="rounded-xl border border-[var(--gold)]/20 bg-background/40 p-5">
      <div className="mb-2 inline-flex h-9 w-9 items-center justify-center rounded-md gradient-gold text-primary-foreground">
        <Icon className="h-4 w-4" />
      </div>
      <h3 className="font-serif text-base text-gradient-gold">{h}</h3>
      <p className="mt-1 text-xs text-muted-foreground">{b}</p>
    </div>
  );
}
