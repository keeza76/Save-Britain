import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { Snapshot } from "@/components/Snapshot";

export const Route = createFileRoute("/manifesto")({ component: Manifesto });

const headlinePledges = [
  "Enact the British Bill of Rights & Freedoms Act",
  "Lawfully withdraw from the European Convention on Human Rights",
  "End the petrol & diesel ban — petrol-car production protected for 500 years",
  "Increase UK petrol-car production by 99%",
  "Abolish Vehicle Excise Duty (car tax / VED) — locked by statute",
  "End the asylum and refugee intake pipeline",
  "Housing First nationally — end street homelessness",
  "Wage indexation against cost of living",
  "Reindustrialise British steel, shipbuilding and manufacturing",
  "Royal Navy and RAF modernisation programme",
  "NHS reconstruction with workforce parity for mental health",
  "Energy independence through balanced nuclear, gas, oil and renewables",
  "Strategic alliance with USA, Canada, Australia, NZ, Italy, Taiwan, Poland, Germany, Japan",
  "Maximise trade with China, USA, Italy, Canada and Commonwealth",
  "Independent National Integrity & Audit Authority",
  "32-year renewal mandate across 25 eras with binding sunset clause",
];

const doctrines = [
  {
    roman: "I",
    title: "Social Settlement Doctrine",
    blocks: [
      {
        h: "Working-Class Priority Guarantee",
        intro: "The state has a defined duty to improve conditions for working citizens before expanding external obligations.",
        items: [
          "Wage growth indexed against national cost-of-living indicators",
          "Mandatory apprenticeship expansion tied to all major infrastructure contracts",
          "National skills pipeline linking education directly to employment sectors",
          "Criminal penalties for systematic wage exploitation",
          "Local employment preference in public contracts",
        ],
      },
      {
        h: "Poverty Reduction State Obligation",
        intro: "Poverty is treated as a structural failure of coordination, not individual circumstance.",
        items: [
          "Legal duty on government to reduce homelessness annually",
          "Housing First model enshrined nationally for all rough sleepers",
          "Emergency accommodation guaranteed as a statutory right",
          "Integrated housing, mental health and addiction support",
          "Long-term goal: structural elimination of street homelessness",
        ],
      },
      {
        h: "Housing Stabilisation",
        intro: "Housing is treated as national infrastructure, not purely market output.",
        items: [
          "National housing supply targets enforced regionally",
          "Fast-track planning zones for affordable housing",
          "Restrictions on long-term vacant property holdings",
          "Priority allocation for UK residents in need and key workers",
          "Public–private delivery under strict affordability caps",
        ],
      },
    ],
  },
  {
    roman: "II",
    title: "Economic Reconstruction Doctrine",
    blocks: [
      {
        h: "Strategic Mixed Coordination Economy",
        intro: "A hybrid system where markets operate freely only within nationally defined stability boundaries.",
        items: [
          "Private sector: innovation, competition, consumer markets",
          "State: strategic direction, infrastructure, stability enforcement",
          "Critical sectors shielded from volatility (energy, defence supply chain, transport)",
        ],
      },
      {
        h: "National Productivity Doctrine",
        intro: "Economic success is measured in output, wage strength and resilience.",
        items: [
          "Domestic manufacturing revival incentives",
          "Energy independence acceleration",
          "SME tax simplification and expansion protection",
          "National Infrastructure Investment Bank",
          "Procurement preference for UK-based supply chains",
        ],
      },
      {
        h: "Industrial Sovereignty",
        intro: "Britain must once again make the things it needs.",
        items: [
          "Revive primary steel and foundry capacity",
          "Rebuild merchant and naval shipbuilding",
          "Strategic UK semiconductor design & packaging",
          "Aerospace, missile, drone and electronics production at scale",
          "Petrol-car production capacity expanded by 99% over the renewal period",
        ],
      },
    ],
  },
  {
    roman: "III",
    title: "Industrial & Automotive Protection Doctrine",
    blocks: [
      {
        h: "Petrol-Car Protection Pledge (500-Year Lock)",
        intro: "A constitutional commitment to defend the British internal-combustion automotive industry for at least 500 years.",
        items: [
          "End the petrol and diesel ban date — and protect petrol-car production for a guaranteed minimum of 500 years",
          "Increase UK petrol-car production capacity by 99%",
          "Cap and limit EV-mandate production quotas",
          "Protect British engine, gearbox and chassis manufacturing jobs",
          "Write the petrol-car protection into the schedule of the Bill of Rights — no future government, court or treaty body may amend, suspend or repeal",
        ],
      },
      {
        h: "Abolish Vehicle Excise Duty (Car Tax)",
        intro: "Vehicle Excise Duty (VED) is mandatory and helps fund public services, but is not allocated to road maintenance — an unfair, regressive tax on lawful drivers.",
        items: [
          "Abolish Vehicle Excise Duty entirely by statute",
          "Fold the lost revenue into general taxation — no replacement road-use tax",
          "Refund VED collected in the final partial year",
          "Lock the abolition into the Bill of Rights schedule — VED cannot be reintroduced",
          "End the punitive emissions-based VED surcharge on older vehicles",
        ],
      },
      {
        h: "Energy Mix Balance",
        intro: "Energy independence through a balanced national mix.",
        items: [
          "Domestic nuclear baseload (SMR + large reactors)",
          "Domestic gas and oil maintained for transition security",
          "Renewables expanded without dependence on hostile supply chains",
          "Repeal of net-zero deadlines that destroy industry without alternatives",
        ],
      },
    ],
  },
  {
    roman: "IV",
    title: "Constitutional & Institutional Order",
    blocks: [
      {
        h: "Dual Authority Constitutional Model",
        intro: "The UK remains a parliamentary democracy under constitutional monarchy with clarified stabilisation roles.",
        items: [
          "Monarch: reinforced symbolic and constitutional continuity role",
          "Monarch: safeguard function during constitutional instability",
          "Prime Minister: full executive control of policy and administration",
          "Prime Minister: accountable to Parliament and public mandate",
          "No legislative power expansion beyond constitutional convention",
        ],
      },
      {
        h: "National Integrity & Audit Framework",
        intro: "A permanent independent layer ensuring state performance accountability.",
        items: [
          "Cross-government efficiency auditing body",
          "Mandatory publication of performance metrics across departments",
          "Anti-corruption enforcement authority with statutory independence",
          "Waste reduction enforcement powers tied to funding reviews",
        ],
      },
    ],
  },
  {
    roman: "V",
    title: "Border & Migration Doctrine",
    blocks: [
      {
        h: "End the Asylum & Refugee Pipeline",
        intro: "Save Britain will lawfully end the open asylum and refugee intake system entirely.",
        items: [
          "Stop all irregular Channel crossings — dismantle smuggling routes",
          "End indefinite asylum and refugee acceptance under inherited frameworks",
          "Withdraw from the 1951 Refugee Convention obligations alongside ECHR reform",
          "Replace with a tightly capped, government-selected resettlement programme",
          "No automatic right to claim asylum on irregular entry",
          "Immediate detention and removal of illegal entrants",
        ],
      },
      {
        h: "Sovereign Migration Control",
        intro: "Lawful migration policy is democratically controlled through structured national referenda.",
        items: [
          "Legal migration: skills-based, controlled, rights-protected",
          "Periodic public vote on migration ceilings and categories",
          "Strong protection of lawful migrants' rights and residency stability",
          "Foreign criminals deportable — no ECHR Article 8 block",
        ],
      },
      {
        h: "Capacity-Based Immigration",
        intro: "Lawful migration levels are directly linked to national capacity indicators.",
        items: ["Housing availability", "NHS system load", "Labour market demand", "Infrastructure strain", "Dynamic adjustment within referendum-defined limits"],
      },
    ],
  },
  {
    roman: "VI",
    title: "National Security & State Capability",
    blocks: [
      {
        h: "Internal Stability",
        intro: "The state must maintain functional security and operational resilience.",
        items: [
          "Expanded border enforcement capability",
          "Cybersecurity and infrastructure protection prioritisation",
          "Expanded recruitment and retention for defence forces",
          "Critical supply chain security safeguards",
        ],
      },
      {
        h: "Defence Modernisation",
        intro: "The Royal Navy, Army and RAF must operate at full sovereign capability.",
        items: [
          "Royal Navy fleet expansion + AUKUS submarine programme",
          "RAF Tempest / GCAP delivery with Italy and Japan",
          "Restored Royal Marines amphibious capability",
          "Joint armour and missile programmes with Poland and Germany",
          "NATO frontline rotational presence in the Baltic",
        ],
      },
    ],
  },
  {
    roman: "VII",
    title: "Foreign Policy & Trade Doctrine",
    blocks: [
      {
        h: "Strategic Alliance Circle",
        intro: "Cooperation concentrated on trusted democratic allies.",
        items: ["United States", "Canada", "Australia", "New Zealand", "Italy", "Taiwan", "Poland", "Germany", "Japan"],
      },
      {
        h: "Wide Global Trade",
        intro: "Trade widely, integrate politically with no one.",
        items: [
          "China and USA as top-volume commercial partners",
          "Italy and Canada as deep bilateral partnerships",
          "Expanded CPTPP and Commonwealth trade",
          "No foreign legislative control over UK law",
        ],
      },
    ],
  },
  {
    roman: "VIII",
    title: "Rights & Civic Order",
    blocks: [
      {
        h: "Rights & Responsibility Charter",
        intro: "Rights are protected under law for citizens and lawful residents, paired with civic obligations.",
        items: [
          "Freedom of expression protected within UK law",
          "Equal protection against discrimination and exploitation",
          "Legal clarity between citizenship, residency and migration status",
          "Enforcement against systemic abuse in labour and housing",
          "Civic responsibility expectations embedded in public systems",
        ],
      },
    ],
  },
];

const plan = [
  { phase: "Phase 1", days: "Days 1–7", items: ["Full government spending audit launched", "Minister performance targets introduced", "Emergency homelessness response activated", "Bill of Rights drafting team appointed"] },
  { phase: "Phase 2", days: "Days 7–14", items: ["British Bill of Rights and Freedoms Act introduced to Parliament", "Asylum-pipeline closure order issued", "Channel-crossing enforcement scaled"] },
  { phase: "Phase 3", days: "Days 14–21", items: ["Petrol-car protection clause drafted into Bill of Rights schedule with 500-year lock", "Repeal of petrol & diesel ban tabled", "EV-mandate quota cap announced", "Vehicle Excise Duty (VED) abolition bill drafted and tabled"] },
  { phase: "Phase 4", days: "Days 21–28", items: ["Housing First enshrined nationally", "Statutory right to emergency accommodation activated", "Fast-track planning zones designated"] },
  { phase: "Phase 5", days: "Days 28–35", items: ["Wage enforcement strengthened", "Apprenticeship expansion launched", "Cost-of-living stabilisation measures introduced"] },
  { phase: "Phase 6", days: "Days 35–42", items: ["Notice of lawful ECHR withdrawal lodged with Council of Europe", "Article 58 process initiated", "Domestic rights transition plan published"] },
  { phase: "Phase 7", days: "Days 42–49", items: ["National Industrial Strategy launched", "Steel, shipbuilding and automotive task forces stood up", "Procurement preference reformed"] },
  { phase: "Phase 8", days: "Days 49–56", items: ["NHS workforce rescue package", "Mental-health parity funding announced", "Hospital capital plan tabled"] },
  { phase: "Phase 9", days: "Days 56–63", items: ["Royal Navy expansion programme approved", "RAF Tempest / GCAP funding confirmed", "AUKUS submarine workshare expanded"] },
  { phase: "Phase 10", days: "Days 63–70", items: ["Foreign Criminal Removal Order activated", "ECHR Article 8 deportation blocks ended", "Border enforcement upgraded"] },
  { phase: "Phase 11", days: "Days 70–77", items: ["Independent National Integrity & Audit Authority established", "Mandatory department metrics published"] },
  { phase: "Phase 12", days: "Days 77–84", items: ["Strategic alliance summit convened with USA, Canada, Australia, NZ, Italy, Taiwan, Poland, Germany, Japan", "NATO defence-tech accord signed"] },
  { phase: "Phase 13", days: "Days 84–91", items: ["Trade expansion missions to China, USA, Italy, Canada", "CPTPP and Indo-Pacific framework deepened"] },
  { phase: "Phase 14", days: "Days 91–98", items: ["British Bill of Rights and Freedoms Act passes Third Reading", "ECHR withdrawal completed", "Sovereign UK rights framework in force"] },
  { phase: "Phase 15", days: "Days 98–100", items: ["First full national performance report published", "Constitutional sunset clause enacted into law", "32-year renewal mandate formally commenced"] },
];

function Manifesto() {
  return (
    <div>
      <PageHeader eyebrow="Manifesto & Doctrine" title="A plan to restore national strength" lead="Long-term national recovery, not short-term politics. Sixteen headline pledges, eight doctrines, and a 15-phase first-100-days plan — delivered across the 32-year national renewal mandate." />

      <Section className="py-8">
        <Snapshot filename="save-britain-headline-pledges">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Headline Pledges</div>
            <h2 className="mt-3 font-serif text-3xl">Sixteen promises that define our manifesto</h2>
            <div className="mt-6 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {headlinePledges.map((p, i) => (
                <div key={p} className="flex items-start gap-3 rounded-lg border border-gold/20 bg-background/40 p-4">
                  <div className="grid h-8 w-8 shrink-0 place-content-center rounded gradient-gold text-xs font-bold text-primary-foreground">{i + 1}</div>
                  <div className="text-sm text-foreground/90">{p}</div>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="py-8">
        <div className="card-premium rounded-2xl p-6">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Jump to doctrine</div>
          <div className="mt-4 flex flex-wrap gap-2">
            {doctrines.map((d) => (
              <a key={d.roman} href={`#doctrine-${d.roman}`} className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-background/40 px-4 py-2 text-xs font-semibold text-foreground/85 transition hover:border-gold hover:bg-gold/10 hover:text-gold">
                <span className="font-serif text-gradient-gold">{d.roman}</span>
                <span>{d.title}</span>
              </a>
            ))}
          </div>
        </div>
      </Section>

      <Section className="pt-4">
        <div className="space-y-16">
          {doctrines.map((d) => (
            <div key={d.roman} id={`doctrine-${d.roman}`} className="scroll-mt-24">
              <Snapshot filename={`save-britain-doctrine-${d.roman}`}>
                <div className="card-premium rounded-2xl p-6 md:p-8">
                  <div className="flex items-baseline gap-5">
                    <span className="font-serif text-4xl text-gradient-gold">{d.roman}</span>
                    <h2 className="font-serif text-2xl md:text-3xl">{d.title}</h2>
                  </div>
                  <div className="hairline my-5" />
                  <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                    {d.blocks.map((b) => (
                      <div key={b.h} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                        <h3 className="font-serif text-lg text-gradient-gold">{b.h}</h3>
                        <p className="mt-2 text-sm text-muted-foreground">{b.intro}</p>
                        <ul className="mt-4 space-y-2 text-sm text-foreground/85">
                          {b.items.map((i) => (
                            <li key={i} className="flex gap-2"><span className="mt-2 inline-block h-1 w-3 shrink-0 bg-gold/70" /><span>{i}</span></li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              </Snapshot>
            </div>
          ))}
        </div>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="save-britain-first-100-days">
          <div className="card-premium rounded-2xl p-8 md:p-10">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">First 100 days · 15 phases</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">From inauguration to legislation</h2>
            <div className="mt-8 space-y-4">
              {plan.map((p) => (
                <div key={p.phase} className="grid gap-4 rounded-xl border border-gold/15 bg-background/40 p-6 md:grid-cols-[200px_1fr]">
                  <div>
                    <div className="font-serif text-xl text-gradient-gold">{p.phase}</div>
                    <div className="text-xs uppercase tracking-widest text-muted-foreground">{p.days}</div>
                  </div>
                  <ul className="grid gap-2 text-sm text-muted-foreground sm:grid-cols-2">
                    {p.items.map((i) => <li key={i}>— {i}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>
    </div>
  );
}
