import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import { Handshake, Ship, Cpu, Globe2 } from "lucide-react";
import { Flag } from "@/components/Flag";
import { Snapshot } from "@/components/Snapshot";

export const Route = createFileRoute("/allies")({
  component: Allies,
  head: () => ({
    meta: [
      { title: "International Allies & Trade — Save Britain" },
      { name: "description", content: "Save Britain's foreign policy: strategic alliance with USA, Canada, Australia, NZ, Italy, Taiwan, Poland, Germany and Japan — plus expanded trade with China, USA, Italy and Canada." },
      { property: "og:title", content: "International Allies & Trade — Save Britain" },
      { property: "og:description", content: "Strategic alliances and expanded global trade for a sovereign Britain." },
    ],
  }),
});

const allies = [
  { code: "us", name: "United States", role: "Top-tier strategic ally. NATO cornerstone. Deep defence, intelligence and trade integration." },
  { code: "ca", name: "Canada", role: "Commonwealth partner. Expanded bilateral trade, energy and defence cooperation." },
  { code: "au", name: "Australia", role: "AUKUS partner. Indo-Pacific security, defence technology, and Commonwealth alliance." },
  { code: "nz", name: "New Zealand", role: "Commonwealth and Five Eyes partner. Intelligence sharing and trade." },
  { code: "it", name: "Italy", role: "Major European ally. NATO partner. GCAP fighter programme. Expanded industrial and technology trade." },
  { code: "tw", name: "Taiwan", role: "Strategic democratic partner in the Indo-Pacific. Semiconductor and technology cooperation." },
  { code: "pl", name: "Poland", role: "Key NATO frontline ally. Defence procurement and joint military exercises." },
  { code: "de", name: "Germany", role: "European industrial and defence partner. Joint engineering and manufacturing programmes." },
  { code: "jp", name: "Japan", role: "Indo-Pacific defence partner. GCAP fighter programme. Advanced technology cooperation." },
];

const tradePartners = [
  { code: "cn", name: "China", note: "Largest trade volume — expanded commercial trade outside critical security sectors." },
  { code: "us", name: "United States", note: "Comprehensive UK–US trade framework across technology, finance and defence." },
  { code: "it", name: "Italy", note: "Expanded EU-friendly trade — manufacturing, automotive, fashion, food." },
  { code: "ca", name: "Canada", note: "Deepened Commonwealth trade pact — energy, agriculture, technology." },
  { code: "au", name: "Australia", note: "Strengthened CPTPP-aligned trade relationship." },
  { code: "jp", name: "Japan", note: "High-tech, automotive and clean-energy trade expansion." },
  { code: "de", name: "Germany", note: "Industrial machinery, automotive and engineering trade." },
  { code: "pl", name: "Poland", note: "Manufacturing and Eastern European logistics hub trade." },
];

function Allies() {
  return (
    <div>
      <PageHeader
        eyebrow="Foreign Policy"
        title="Britain's Allies & Trade Partners"
        lead="A sovereign Britain works closely with a defined circle of trusted democratic allies — and trades widely with the world's largest economies for national prosperity."
      />

      <Section>
        <Snapshot filename="save-britain-strategic-allies">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Strategic alliance circle</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">Britain's nine core international partners</h2>
            <p className="mt-3 max-w-3xl text-muted-foreground">
              Save Britain will concentrate diplomatic, defence and intelligence cooperation on a deliberately
              focused group of democratic allies — strengthening trust, interoperability and shared strategic depth.
            </p>
            <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {allies.map((a) => (
                <div key={a.name} className="rounded-xl border border-gold/15 bg-background/40 p-6">
                  <div className="flex items-center gap-4">
                    <Flag code={a.code} className="h-10 w-14 rounded-md shadow ring-1 ring-black/40" />
                    <h3 className="font-serif text-xl text-gradient-gold">{a.name}</h3>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">{a.role}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <Pillar icon={Handshake} h="Trusted Circle" b="Cooperation concentrated on stable democratic allies — not spread thinly." />
          <Pillar icon={Ship} h="NATO Backbone" b="Reinvigorated UK contribution to NATO defence, deterrence and frontline security." />
          <Pillar icon={Cpu} h="Military-Tech Sharing" b="Expanded joint defence-tech — GCAP, AUKUS, cyber and AI." />
          <Pillar icon={Globe2} h="Trade Without Subjugation" b="Wide global trade. No political integration. No external legislative control over UK law." />
        </div>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="save-britain-trade-partners">
          <div className="card-premium rounded-2xl p-8">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Trade expansion</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">Britain trades widely — China, USA, Italy, Canada and beyond</h2>
            <p className="mt-3 max-w-3xl text-muted-foreground">
              Britain will pursue the largest possible commercial trade footprint — with China and the United States
              as our two highest-volume partners, Italy and Canada as deep bilateral partnerships, and expanded
              trade across the Commonwealth and Indo-Pacific.
            </p>
            <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
              {tradePartners.map((t) => (
                <div key={t.name} className="rounded-xl border border-gold/15 bg-background/40 p-5">
                  <div className="flex items-center gap-3">
                    <Flag code={t.code} className="h-8 w-12 rounded-sm shadow ring-1 ring-black/40" />
                    <h3 className="font-serif text-lg">{t.name}</h3>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">{t.note}</p>
                </div>
              ))}
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <Snapshot filename="save-britain-nato-tech">
          <div className="card-premium rounded-2xl p-10">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">NATO Military Technology</div>
            <h3 className="mt-3 font-serif text-2xl md:text-3xl">Deepened defence-tech cooperation with NATO allies</h3>
            <div className="mt-6 grid gap-4 md:grid-cols-2 text-sm text-muted-foreground">
              <div>— Global Combat Air Programme (GCAP) with Italy and Japan</div>
              <div>— AUKUS submarine and advanced capabilities pact with USA and Australia</div>
              <div>— Joint cyber-defence with USA, Canada, Australia and NZ (Five Eyes)</div>
              <div>— Joint armoured vehicle and missile programmes with Poland and Germany</div>
              <div>— Semiconductor and chip-design partnership with Taiwan</div>
              <div>— NATO frontline rotational deployments in Poland and the Baltic</div>
            </div>
          </div>
        </Snapshot>
      </Section>

      <Section className="pt-0">
        <div className="card-premium rounded-2xl p-10 text-center">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Foreign Policy Principle</div>
          <blockquote className="mx-auto mt-4 max-w-3xl font-serif text-2xl leading-relaxed md:text-3xl">
            “Strong alliances, wide trade, <span className="text-gradient-gold">no foreign rule.</span>”
          </blockquote>
        </div>
      </Section>
    </div>
  );
}

function Pillar({ icon: Icon, h, b }: { icon: React.ComponentType<{ className?: string }>; h: string; b: string }) {
  return (
    <div className="card-premium rounded-xl p-6">
      <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
        <Icon className="h-5 w-5" />
      </div>
      <h3 className="font-serif text-base text-gradient-gold">{h}</h3>
      <p className="mt-2 text-xs text-muted-foreground">{b}</p>
    </div>
  );
}
