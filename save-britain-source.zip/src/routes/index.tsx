import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Shield, Landmark, Heart, Fuel, Anchor, Crown, Building2, Globe2, Scale, Users, HandCoins, FileText, Clock, Handshake, Factory } from "lucide-react";
import logoMark from "@/assets/logo-mark.png";
import { Flag, ALLY_CODES } from "@/components/Flag";

export const Route = createFileRoute("/")({ component: Home });

const pillars = [
  { icon: Scale, title: "Social Democracy", body: "A permanent welfare state, fair wages, progressive taxation, and equal opportunity for every citizen." },
  { icon: Heart, title: "Strong NHS", body: "Universal public healthcare, strengthened and protected — free at the point of use, always." },
  { icon: Building2, title: "Industrial Renewal", body: "Rebuild British manufacturing, engineering, gaming and technology for the next generation." },
  { icon: HandCoins, title: "Working-Class Priority", body: "Wages indexed to cost of living, apprenticeship expansion, criminal penalties for wage exploitation." },
  { icon: Users, title: "End Street Homelessness", body: "Housing First enshrined nationally. Statutory right to emergency accommodation." },
  { icon: Shield, title: "End Asylum Pipeline", body: "Stop asylum and refugee intake. Replace with a sovereign, capped UK resettlement system." },
  { icon: Anchor, title: "Defence & Sovereignty", body: "Royal Navy expansion, RAF upgrades, NATO defence-tech cooperation, independent UK decision-making." },
  { icon: Crown, title: "Constitutional Balance", body: "Dual authority: a stabilising constitutional monarchy alongside decisive parliamentary governance." },
  { icon: Fuel, title: "Protect Petrol Cars · 500 Years", body: "End the petrol & diesel ban date. Boost UK petrol-car production by 99%. Protected for 500 years. Locked by statute." },
  { icon: Factory, title: "Reindustrialise Britain", body: "Steel, shipbuilding, automotive, semiconductors, aerospace — strategic public-private investment." },
  { icon: Globe2, title: "One Nation", body: "No region left behind. National infrastructure balanced across every UK constituency." },
  { icon: Landmark, title: "Audit & Integrity", body: "Independent anti-corruption authority. Mandatory performance metrics across all departments." },
];

const pledges = [
  "Enact the British Bill of Rights & Freedoms Act",
  "Lawfully withdraw from the European Convention on Human Rights",
  "End the petrol & diesel car ban — 500-year petrol-car protection locked by statute",
  "Increase UK petrol-car production by 99% over the renewal period",
  "Abolish Vehicle Excise Duty (car tax / VED) — locked in the Bill of Rights schedule",
  "End the asylum & refugee intake pipeline",
  "Housing First nationally — end street homelessness",
  "Wage indexation against cost-of-living",
  "Royal Navy & RAF modernisation programme",
  "Reindustrialise British steel, shipbuilding & manufacturing",
  "32-year national renewal mandate across 25 eras with statutory sunset clause",
];

function Home() {
  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 gradient-green-gold opacity-30" />
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_20%,oklch(0.4_0.1_85/0.25),transparent_50%)]" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-24 md:grid-cols-2 md:py-32">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-background/60 px-3 py-1 text-xs uppercase tracking-[0.25em] text-gold">
              <span className="h-1.5 w-1.5 rounded-full bg-gold" /> A movement in formation
            </div>
            <h1 className="font-serif text-5xl font-semibold leading-[1.05] md:text-7xl">
              <span className="text-foreground">Save </span>
              <span className="text-gradient-gold">Britain.</span>
              <br />
              <span className="text-foreground/90">Restore the Nation.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-muted-foreground">
              A fully Social Democratic British movement built on fairness, stability, national unity,
              industrial revival and modern state efficiency — operating through a Nordic-style efficient state,
              a regulated social market economy, and a One-Nation framework.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/join" className="inline-flex items-center gap-2 rounded-md gradient-gold px-6 py-3 text-sm font-semibold text-primary-foreground glow-cyan hover:opacity-95">
                Join the movement <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/manifesto" className="inline-flex items-center gap-2 rounded-md border border-[var(--gold)]/40 bg-background/40 px-6 py-3 text-sm font-semibold text-[var(--gold)] hover:bg-[var(--gold)]/10">
                Read the manifesto
              </Link>
              <a href="/save-britain-poster.png" download className="inline-flex items-center gap-2 rounded-md border border-[var(--gold)]/20 px-6 py-3 text-sm font-semibold text-foreground/80 hover:border-[var(--gold)]/50">
                Download the poster
              </a>
            </div>
            <div className="mt-10 grid max-w-md grid-cols-4 gap-4 text-xs uppercase tracking-widest text-muted-foreground">
              <div><div className="font-serif text-2xl text-gradient-gold">100%</div>Social Democracy</div>
              <div><div className="font-serif text-2xl text-gradient-gold">32yr</div>Renewal</div>
              <div><div className="font-serif text-2xl text-gradient-gold">25</div>Delivery Eras</div>
              <div><div className="font-serif text-2xl text-gradient-gold">500yr</div>Petrol Lock</div>
            </div>
          </div>
          <div className="relative mx-auto aspect-square w-full max-w-md">
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-secondary/40 via-transparent to-gold/30 blur-3xl" />
            <div className="relative flex h-full items-center justify-center">
              <img src={logoMark} alt="Save Britain crest" className="h-full w-full rounded-full bg-white object-contain p-3 shadow-[0_20px_80px_rgba(212,175,55,0.25)] ring-4 ring-gold/30" />
            </div>
          </div>
        </div>
      </section>

      {/* IDENTITY LINE */}
      <section className="border-y border-border/50 bg-background/40">
        <div className="mx-auto max-w-5xl px-6 py-20 text-center">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Core Political Identity</div>
          <h2 className="mt-4 font-serif text-3xl md:text-4xl">
            “A <span className="text-gradient-gold">Social Democratic Britain</span> built on fairness, stability, national unity, and modern state efficiency.”
          </h2>
        </div>
      </section>

      {/* KEY PLEDGES */}
      <section className="mx-auto max-w-7xl px-6 py-24">
        <div className="mb-10 text-center">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Our Headline Pledges</div>
          <h2 className="mt-3 font-serif text-3xl md:text-4xl">Eleven promises we will not break</h2>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {pledges.map((p, i) => (
            <div key={p} className="card-premium flex items-start gap-4 rounded-xl p-5">
              <div className="grid h-9 w-9 shrink-0 place-content-center rounded-md gradient-gold font-serif text-sm text-primary-foreground">{i + 1}</div>
              <div className="text-sm text-foreground/90 pt-1">{p}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURE TRIO */}
      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="grid gap-6 md:grid-cols-3">
          <FeatureCard
            to="/bill-of-rights"
            icon={FileText}
            eyebrow="Flagship Legislation"
            title="British Bill of Rights & Freedoms Act"
            body="Sovereign UK rights, lawful ECHR withdrawal, deportation powers restored, free speech protected, asylum pipeline closed."
            cta="Read the Bill"
          />
          <FeatureCard
            to="/timeline"
            icon={Clock}
            eyebrow="The Renewal Doctrine"
            title="The 32-Year National Renewal Period"
            body="One uninterrupted delivery mandate across 25 eras to rebuild Britain. Then the 5-year electoral cycle automatically resumes by sunset clause."
            cta="See the 25 eras"
          />
          <FeatureCard
            to="/allies"
            icon={Handshake}
            eyebrow="Foreign Policy"
            title="Allies, NATO & Global Trade"
            body="Deep alliance with USA, Canada, Australia, NZ, Italy, Taiwan, Poland, Germany & Japan. Expanded trade with China and beyond."
            cta="See our allies"
          />
        </div>
      </section>

      {/* PILLARS */}
      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="mb-12 flex items-end justify-between gap-6">
          <div>
            <div className="text-xs uppercase tracking-[0.3em] text-gold">What we stand for</div>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">Twelve pillars of national renewal</h2>
          </div>
          <Link to="/policies" className="hidden text-sm text-gold hover:underline md:inline-flex">All policies →</Link>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {pillars.map((p) => (
            <div key={p.title} className="card-premium group rounded-xl p-6 transition-transform hover:-translate-y-1">
              <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
                <p.icon className="h-5 w-5" />
              </div>
              <h3 className="font-serif text-lg">{p.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{p.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ALLIES STRIP */}
      <section className="border-y border-border/50 bg-background/40">
        <div className="mx-auto max-w-6xl px-6 py-14 text-center">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Standing with our allies</div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-4">
            {ALLY_CODES.map((c) => <Flag key={c} code={c} className="h-10 w-14 rounded-md shadow-lg ring-1 ring-black/40" />)}
          </div>
          <p className="mx-auto mt-6 max-w-2xl text-sm text-muted-foreground">
            Britain · United States · Canada · Australia · New Zealand · Italy · Taiwan · Poland · Germany · Japan
          </p>
          <Link to="/allies" className="mt-6 inline-flex text-sm text-gold hover:underline">Read the foreign policy →</Link>
        </div>
      </section>

      {/* QUOTE / CTA */}
      <section className="relative overflow-hidden border-y border-border/60 bg-background/60">
        <div className="absolute inset-0 -z-10 gradient-green-gold opacity-20" />
        <div className="mx-auto max-w-4xl px-6 py-24 text-center">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">A founding principle</div>
          <blockquote className="mt-6 font-serif text-2xl leading-relaxed md:text-4xl">
            “Britain succeeds when its institutions are stable, its economy productive,
            its communities supported, and its future planned with <span className="text-gradient-gold">clarity and purpose</span>.”
          </blockquote>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/join" className="rounded-md gradient-gold px-6 py-3 text-sm font-semibold text-primary-foreground glow-cyan">Stand with Britain</Link>
            <a href="/save-britain-poster.png" download className="rounded-md border border-[var(--gold)]/40 px-6 py-3 text-sm font-semibold text-[var(--gold)] hover:bg-[var(--gold)]/10">Download the poster</a>
            <a href="/save-britain-source.zip" download className="rounded-md border border-[var(--gold)]/40 px-6 py-3 text-sm font-semibold text-[var(--gold)] hover:bg-[var(--gold)]/10">Download site files (ZIP)</a>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ to, icon: Icon, eyebrow, title, body, cta }: { to: string; icon: React.ComponentType<{ className?: string }>; eyebrow: string; title: string; body: string; cta: string }) {
  return (
    <Link to={to} className="card-premium group flex flex-col rounded-2xl p-8 transition-all hover:-translate-y-1 hover:border-gold/40">
      <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg gradient-gold text-primary-foreground">
        <Icon className="h-6 w-6" />
      </div>
      <div className="text-[10px] uppercase tracking-[0.3em] text-gold">{eyebrow}</div>
      <h3 className="mt-2 font-serif text-2xl text-gradient-gold">{title}</h3>
      <p className="mt-3 flex-1 text-sm text-muted-foreground">{body}</p>
      <div className="mt-5 inline-flex items-center gap-1 text-sm text-gold">
        {cta} <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  );
}
