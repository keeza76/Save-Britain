import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, Section } from "@/components/Section";
import logoMark from "@/assets/logo-mark.png";

export const Route = createFileRoute("/about")({ component: About });

const ideology = [
  { tag: "Primary", title: "Full Social Democracy", body: "Permanent welfare state, universal NHS, strong worker protections, progressive taxation, publicly funded essential services, homelessness reduction as national obligation." },
  { tag: "Efficiency", title: "Nordic-Style Governance", body: "High-performing public services, long-term planning, strong education and skills systems, low-corruption governance standards." },
  { tag: "Structure", title: "Social Market Economy", body: "Capitalism with regulation. Strong, fair private sector. Protection of SMEs. Strategic public investment. Growth tied to living standards, not profit alone." },
  { tag: "Unity", title: "One-Nation Principle", body: "No region left behind. Balanced national infrastructure investment. Equal access to opportunity across the United Kingdom." },
  { tag: "Industry", title: "Industrial Protection", body: "Reindustrialisation of steel, shipbuilding, automotive, aerospace and semiconductors. Statutory protection of petrol-car production." },
  { tag: "Lawful", title: "Border & Migration Framework", body: "Strict enforcement against illegal entry. End of the asylum pipeline. Migration aligned with national capacity. Lawful migrant rights protected." },
  { tag: "Security", title: "Defence & National Security", body: "Royal Navy expansion, RAF upgrades, cyber-defence investment, infrastructure protection, NATO frontline contribution." },
  { tag: "Order", title: "Constitutional Democracy", body: "Parliamentary democracy. Constitutional monarchy. Rule of law. Independent judiciary. Peaceful political transition." },
];

function About() {
  return (
    <div>
      <PageHeader
        eyebrow="About the Movement"
        title="A nation worth building for"
        lead="Save Britain is a democratic, constitutional political movement whose core economic and social model is 100% aligned with Social Democracy — supported by Nordic-style public efficiency and a social market economy framework."
      />
      <Section>
        <div className="grid gap-12 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6 text-foreground/90">
            <p>
              Save Britain was founded on the belief that the country succeeds when its institutions are stable,
              its economy is productive, its communities are supported, and its future is planned with clarity and purpose.
            </p>
            <p>
              We are explicitly and fully committed to Social Democracy as our core governing ideology — a strong
              welfare state, universal healthcare, fair wages, active intervention to reduce poverty, and progressive
              taxation to fund public investment. The role of the state is to actively ensure economic fairness,
              social protection, and equal opportunity for every citizen.
            </p>
            <p>
              Built on the principles of structured democracy, national renewal, constitutional balance, economic
              growth, public investment, and sovereign cooperation, Save Britain seeks to create a stronger, safer,
              and more united nation through long-term planning rather than short-term political cycles.
            </p>

            <h3 className="font-serif text-2xl text-gradient-gold pt-4">The 32-Year Renewal Period</h3>
            <p>
              To deliver structural reform effectively, the movement proposes a temporary 32-year national renewal
              period across <Link to="/timeline" className="text-gold hover:underline">twelve delivery eras</Link>,
              during which long-term change can be implemented under stable leadership. Following that period,
              the standard 5-year electoral cycle resumes automatically by sunset clause, with a general election
              triggered within 30 days.
            </p>

            <h3 className="font-serif text-2xl text-gradient-gold pt-4">Flagship Legislation</h3>
            <p>
              Our central legislative project is the{" "}
              <Link to="/bill-of-rights" className="text-gold hover:underline">British Bill of Rights and Freedoms Act</Link> —
              a sovereign UK rights framework replacing the European Convention on Human Rights, ending the asylum
              pipeline, and locking permanent protections for British industry into its Schedule.
            </p>

            <h3 className="font-serif text-2xl text-gradient-gold pt-4">Status</h3>
            <p>
              Save Britain is currently a developing political movement. It is not yet formally registered with the
              Electoral Commission. We intend to begin structured national campaigning and fundraising in late 2027,
              build our membership and branch structure through 2027–2028, and submit a formal application for
              registration as a UK political party by 14 May 2028, or no later than 2029.
            </p>
          </div>
          <aside className="space-y-6">
            <div className="rounded-2xl bg-white p-4 ring-1 ring-gold/30">
              <img src={logoMark} alt="Save Britain emblem" className="w-full rounded-xl" />
            </div>
            <div className="card-premium rounded-xl p-6">
              <div className="text-xs uppercase tracking-[0.25em] text-gold">Core principles</div>
              <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                <li>— Full Social Democracy</li>
                <li>— Nordic-style efficiency</li>
                <li>— Social market economy</li>
                <li>— One-Nation unity</li>
                <li>— Parliamentary democracy</li>
                <li>— Constitutional monarchy</li>
                <li>— Rule of law</li>
                <li>— Independent judiciary</li>
                <li>— National sovereignty</li>
                <li>— Industrial protection</li>
              </ul>
            </div>
          </aside>
        </div>

        <div className="mt-16">
          <div className="text-xs uppercase tracking-[0.3em] text-gold">Ideological Position</div>
          <h2 className="mt-3 font-serif text-3xl md:text-4xl">Eight foundations of the party</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            {ideology.map((i) => (
              <div key={i.title} className="card-premium rounded-xl p-6">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">{i.tag}</div>
                <h3 className="mt-2 font-serif text-xl">{i.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{i.body}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>
    </div>
  );
}
