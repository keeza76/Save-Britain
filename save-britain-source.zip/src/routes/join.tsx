import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Section } from "@/components/Section";
import { Check } from "lucide-react";

export const Route = createFileRoute("/join")({ component: Join });

function Join() {
  const [submitted, setSubmitted] = useState(false);
  return (
    <div>
      <PageHeader eyebrow="Join the movement" title="Stand with Britain" lead="Register your interest. Help shape the movement before formal registration in 2028." />
      <Section>
        <div className="grid gap-10 md:grid-cols-[1.2fr_1fr]">
          <form
            onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
            className="card-premium space-y-5 rounded-2xl p-8"
          >
            {submitted ? (
              <div className="text-center py-10">
                <div className="mx-auto mb-4 grid h-14 w-14 place-content-center rounded-full gradient-gold text-primary-foreground">
                  <Check className="h-6 w-6" />
                </div>
                <h3 className="font-serif text-2xl text-gradient-gold">Thank you</h3>
                <p className="mt-2 text-sm text-muted-foreground">Your interest has been registered. We'll be in touch as the movement grows.</p>
              </div>
            ) : (
              <>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Full name" name="name" required />
                  <Field label="Email" name="email" type="email" required />
                  <Field label="Postcode" name="postcode" />
                  <Field label="Constituency (if known)" name="constituency" />
                </div>
                <div>
                  <label className="mb-2 block text-xs uppercase tracking-widest text-muted-foreground">How would you like to help?</label>
                  <textarea name="message" rows={4} className="w-full rounded-md border border-gold/20 bg-background/60 px-3 py-2 text-sm focus:border-gold focus:outline-none" placeholder="Volunteering, organising, donations, ideas…" />
                </div>
                <label className="flex items-start gap-3 text-xs text-muted-foreground">
                  <input type="checkbox" required className="mt-1 accent-[oklch(0.78_0.12_85)]" />
                  I confirm I am a UK resident eligible to vote and I support the principles of Save Britain.
                </label>
                <button className="w-full rounded-md gradient-gold px-6 py-3 text-sm font-semibold text-primary-foreground">
                  Register my interest
                </button>
              </>
            )}
          </form>

          <aside className="space-y-5">
            <div className="card-premium rounded-xl p-6">
              <div className="text-xs uppercase tracking-[0.25em] text-gold">Why join now</div>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li>— Shape policy before formal launch</li>
                <li>— Help build local branches across the UK</li>
                <li>— Be first to know about events and campaigns</li>
                <li>— Join a movement built on long-term thinking</li>
              </ul>
            </div>
            <div className="rounded-xl border border-gold/20 bg-background/40 p-6 text-xs text-muted-foreground">
              <strong className="text-gold">Note:</strong> Save Britain is a political movement in formation and is not yet
              registered with the Electoral Commission. Membership and donations will open formally upon registration.
              Registering your interest creates no legal membership at this stage.
            </div>
          </aside>
        </div>
      </Section>
    </div>
  );
}

function Field({ label, name, type = "text", required = false }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="mb-2 block text-xs uppercase tracking-widest text-muted-foreground">{label}</label>
      <input
        name={name} type={type} required={required}
        className="w-full rounded-md border border-gold/20 bg-background/60 px-3 py-2 text-sm focus:border-gold focus:outline-none"
      />
    </div>
  );
}
